import os
from flask import Flask, render_template

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

@app.route('/')
def homepage():
    return render_template('index.html', active_page='homepage')

@app.route('/terminal')
def terminal():
    return render_template('terminal.html', active_page='terminal')

@app.route('/relatorio')
def relatorio():
    return render_template('relatorio.html', active_page='relatorio')

@app.route('/creditos')
def creditos():
    return render_template('creditos.html', active_page='creditos')

@app.route('/financeiro')
def financeiro():
    return render_template('financeiro.html', active_page='financeiro')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
