# TCC AMD-207 Flask Application

## Overview

This is a Flask-based web application for a TCC (Final Course Project) presentation system themed around Fallout/Vault-Tec aesthetics. The application provides a multi-page interface with navigation between different sections including homepage, video terminal, project report, credits, and financial information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **Base Template Pattern**: Uses template inheritance with `base.html` as the main layout
- **Responsive Design**: Mobile-first approach with collapsible sidebar navigation
- **Styling**: Custom CSS with retro terminal/Vault-Tec theme using green-on-dark color scheme
- **JavaScript**: Vanilla JavaScript for interactive components (slider, video controls, mobile menu)

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Structure**: Simple single-file application (`app.py`) with route handlers
- **Session Management**: Flask sessions with configurable secret key
- **Development Setup**: Debug mode enabled for development environment

## Key Components

### Application Structure
- **Main Application** (`app.py`): Contains all route definitions and Flask configuration
- **Entry Point** (`main.py`): Simple import wrapper for the Flask app
- **Templates Directory**: Jinja2 HTML templates with shared base layout
- **Static Assets**: CSS stylesheets and JavaScript files for frontend functionality

### Navigation System
- **Sidebar Navigation**: Fixed left sidebar with responsive mobile toggle
- **Active State Management**: Template-based active page highlighting
- **Mobile Support**: Hamburger menu with overlay for mobile devices

### Page Components
1. **Homepage** (`index.html`): Main landing page with numbered menu items
2. **Terminal** (`terminal.html`): Video player with custom controls
3. **Report** (`relatorio.html`): Slide-based presentation system
4. **Credits** (`creditos.html`): Team and technology credits
5. **Financial** (`financeiro.html`): Budget and financial status display

## Data Flow

### Request Flow
1. User requests a route (e.g., `/terminal`)
2. Flask route handler processes the request
3. Template is rendered with context data (`active_page` parameter)
4. HTML response is sent to client with appropriate active navigation state

### Frontend Interactions
- **Mobile Menu**: JavaScript toggles sidebar visibility on mobile devices
- **Video Controls**: Custom video player controls with play/pause and timer
- **Slider Navigation**: Arrow-key and button navigation for report slides

## External Dependencies

### Python Dependencies
- **Flask**: Web framework for Python
- **Jinja2**: Template engine (included with Flask)

### Frontend Dependencies
- **Font Awesome**: Icon library via CDN (version 6.0.0)
- **External Video**: Sample video hosted on Google Cloud Storage

### Browser APIs
- **HTML5 Video API**: For custom video player functionality
- **CSS Grid/Flexbox**: For responsive layout system
- **LocalStorage**: Potential for future state persistence

## Deployment Strategy

### Environment Configuration
- **Secret Key**: Configurable via `SESSION_SECRET` environment variable
- **Host/Port**: Configured for `0.0.0.0:5000` to allow external connections
- **Debug Mode**: Currently enabled for development

### Static File Serving
- Flask's built-in static file serving for CSS/JS assets
- External CDN for Font Awesome icons
- External hosting for video content

### Scalability Considerations
- Single-file application structure suitable for small-scale deployment
- No database dependencies - fully static content
- Ready for containerization with minimal configuration
- Environment variables support for production configuration

### Future Enhancements
- Database integration potential (Drizzle ORM ready)
- User authentication system expandability
- Content management system integration
- Progressive Web App (PWA) capabilities with existing responsive design