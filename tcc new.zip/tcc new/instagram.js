
// Instagram Profile Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    
    // Tab switching functionality
    const tabs = document.querySelectorAll('.instagram-posts-tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Here you could implement different content loading
            // For now, we'll just keep the same posts grid
            console.log('Tab clicked:', this.textContent.trim());
        });
    });
    
    // Post hover effects (already handled by CSS, but we can add click functionality)
    const posts = document.querySelectorAll('.instagram-post');
    
    posts.forEach(post => {
        post.addEventListener('click', function() {
            console.log('Post clicked:', this.dataset.testid);
            // Here you could implement a modal to show the full post
        });
    });
    
    // Story highlights click functionality
    const highlights = document.querySelectorAll('.instagram-highlight');
    
    highlights.forEach(highlight => {
        highlight.addEventListener('click', function() {
            console.log('Highlight clicked:', this.dataset.testid);
            // Here you could implement story viewing functionality
        });
    });
    
    // Follow button functionality
    const followBtn = document.querySelector('.instagram-follow-btn');
    
    if (followBtn) {
        followBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (this.textContent === 'Seguindo') {
                this.textContent = 'Seguir';
                this.style.backgroundColor = '#0095f6';
                console.log('Unfollowed');
            } else {
                this.textContent = 'Seguindo';
                this.style.backgroundColor = '#262626';
                console.log('Followed');
            }
        });
    }
    
    // Message button functionality
    const messageBtn = document.querySelector('.instagram-message-btn');
    
    if (messageBtn) {
        messageBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Message button clicked');
            // Here you could implement messaging functionality
        });
    }
    
    // More options button functionality
    const moreBtn = document.querySelector('.instagram-more-btn');
    
    if (moreBtn) {
        moreBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('More options clicked');
            // Here you could implement a dropdown menu
        });
    }
    
    // Sidebar navigation functionality
    const navItems = document.querySelectorAll('.sidebar-nav-item');
    
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all nav items
            navItems.forEach(nav => nav.classList.remove('active'));
            
            // Add active class to clicked item
            this.classList.add('active');
            
            console.log('Navigation clicked:', this.dataset.testid);
        });
    });
    
    // Smooth scroll for highlights container
    const highlightsContainer = document.querySelector('.instagram-highlights-container');
    
    if (highlightsContainer) {
        let isDown = false;
        let startX;
        let scrollLeft;
        
        highlightsContainer.addEventListener('mousedown', (e) => {
            isDown = true;
            startX = e.pageX - highlightsContainer.offsetLeft;
            scrollLeft = highlightsContainer.scrollLeft;
        });
        
        highlightsContainer.addEventListener('mouseleave', () => {
            isDown = false;
        });
        
        highlightsContainer.addEventListener('mouseup', () => {
            isDown = false;
        });
        
        highlightsContainer.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - highlightsContainer.offsetLeft;
            const walk = (x - startX) * 2;
            highlightsContainer.scrollLeft = scrollLeft - walk;
        });
    }
    
    // Lazy loading for images (simple implementation)
    const images = document.querySelectorAll('img');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.style.opacity = '0';
                img.style.transition = 'opacity 0.3s';
                
                img.onload = function() {
                    this.style.opacity = '1';
                };
                
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => {
        imageObserver.observe(img);
    });
    
    // Mobile menu toggle (if needed in future)
    function toggleMobileMenu() {
        const sidebar = document.querySelector('.instagram-sidebar');
        sidebar.classList.toggle('mobile-open');
    }
    
    // Add some dynamic loading animations
    function addLoadingAnimation() {
        const posts = document.querySelectorAll('.instagram-post img');
        
        posts.forEach((img, index) => {
            img.style.opacity = '0';
            img.style.transform = 'scale(0.8)';
            img.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            
            setTimeout(() => {
                img.style.opacity = '1';
                img.style.transform = 'scale(1)';
            }, index * 100);
        });
    }
    
    // Initialize loading animation
    setTimeout(addLoadingAnimation, 100);
    
    // Stats counter animation
    function animateStats() {
        const stats = document.querySelectorAll('.instagram-stat-number');
        
        stats.forEach(stat => {
            const text = stat.textContent;
            stat.style.opacity = '0';
            
            setTimeout(() => {
                stat.style.transition = 'opacity 0.5s ease';
                stat.style.opacity = '1';
            }, 200);
        });
    }
    
    // Initialize stats animation
    setTimeout(animateStats, 300);
    
    console.log('Instagram profile page loaded successfully!');
});