// script.js

// Tempo total da animação dos itens da lista
const totalTypingTime = 7.5 * 1000;

window.addEventListener('load', () => {
  // Espera terminar a animação de digitação antes de mostrar o terminal
  setTimeout(() => {
    const terminal = document.getElementById('terminal-video');
    terminal.style.animationPlayState = 'running';
  }, totalTypingTime);
});

// Controle de vídeo estilo terminal
const video = document.getElementById('video');
const playBtn = document.getElementById('playPauseBtn');
const timer = document.getElementById('timer');

// Função para formatar o tempo
function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

// Play/Pause
playBtn.addEventListener('click', () => {
  if (video.paused) {
    video.play();
    playBtn.textContent = '⏸ Pausar';
  } else {
    video.pause();
    playBtn.textContent = '▶ Reproduzir';
  }
});

// Atualiza tempo
video.addEventListener('timeupdate', () => {
  timer.textContent = `${formatTime(video.currentTime)} / ${formatTime(video.duration)}`;
});

// Reseta botão ao fim do vídeo
video.addEventListener('ended', () => {
  playBtn.textContent = '▶ Reproduzir';
});
